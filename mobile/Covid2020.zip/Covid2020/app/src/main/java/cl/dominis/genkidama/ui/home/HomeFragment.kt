package cl.dominis.genkidama.ui.home

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import cl.dominis.genkidama.R
import cl.dominis.genkidama.controllers.services.MainRequest
import cl.dominis.genkidama.interfaces.RequestServerInterface
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.fragment_home.*


class HomeFragment : Fragment() , OnMapReadyCallback, GoogleMap.OnMyLocationChangeListener,
    GoogleMap.OnMyLocationButtonClickListener, GoogleMap.OnMyLocationClickListener,
    RequestServerInterface {

    private lateinit var homeViewModel: HomeViewModel
    private lateinit var map : GoogleMap
    private var myLatLng: LatLng? = null
    private var zoomed = false
    private lateinit var root : View
    private  val GET_WHEATER_RISK = 1;
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?


    ): View? {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel::class.java)
        root = inflater.inflate(R.layout.fragment_home, container, false)

        configureMaps()
        updateData()
        return root
    }


    fun updateData()
    {
        root.findViewById<TextView>(R.id.textViewNearCases).setText("25 (<500m)")
        root.findViewById<TextView>(R.id.textViewTemperature).setText("high (22 ºC)")

    }
    fun configureMaps()
    {

        (this.childFragmentManager?.findFragmentById(R.id.map) as SupportMapFragment).getMapAsync(this)

    }

    override fun onMapReady(map_v: GoogleMap?) {
        if(map_v == null)
        {
            return
        }

        map = map_v!!

        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(context!!,
                Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {


                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(activity!!,
                    arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
                    1)

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.

        } else {

            setMapLocationFunction()
        }


    }

    fun setMapLocationFunction()
    {
        map.isMyLocationEnabled = true
        map.setOnMyLocationChangeListener(this)
        map.setOnMyLocationButtonClickListener(this)
        map.setOnMyLocationClickListener(this)
    }

    fun updateInformation()
    {
        if(myLatLng == null)
        {
            return
        }
        map.addMarker(
            MarkerOptions()
                .position(myLatLng!!)
                .title("Hello world")
        )
        if(!zoomed)
        {
            zoomMylocation()
            zoomed = true
        }
    }

    fun zoomMylocation(): Boolean {

        if(myLatLng != null)
        {
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(myLatLng,10f))

        }
        return true
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            1 -> {
                // If request is cancelled, the result arrays are empty.
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    setMapLocationFunction()
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return
            }

            // Add other 'when' lines to check for other
            // permissions this app might request.
            else -> {
                // Ignore all other requests.
            }
        }
    }

    override fun onMyLocationChange(p0: Location?) {
        if(p0 != null) {
            myLatLng = LatLng(p0.latitude, p0.longitude)
            updateInformation()
            if(!zoomed)
            {
                zoomMylocation()
                zoomed = true
            }
            getRiskWeatheRisk()
        }
    }

    fun getRiskWeatheRisk() {
        var url  = getString(R.string.url_get_weather_risk)+"lat="+myLatLng!!.latitude+"&long="+myLatLng!!.longitude
        var requestController = MainRequest(this)
        requestController.requestGet(url,GET_WHEATER_RISK)
    }


    override fun onMyLocationButtonClick(): Boolean {
        zoomMylocation()
        return true
    }

    override fun onMyLocationClick(p0: Location) {

    }

    override fun returnData(response: String?, result: Any?, flag: Int) {

    }
}
