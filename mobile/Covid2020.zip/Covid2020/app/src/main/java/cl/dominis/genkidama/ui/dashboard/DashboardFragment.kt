package cl.dominis.genkidama.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import cl.dominis.genkidama.R
import kotlinx.android.synthetic.main.fragment_dashboard.*

class DashboardFragment : Fragment() {

    private lateinit var dashboardViewModel: DashboardViewModel
    var rootView : View? = null
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel::class.java)
        rootView = inflater.inflate(R.layout.fragment_dashboard, container, false)
        setData()
        return rootView
    }

    fun setData()
    {
        rootView?.findViewById<TextView>(R.id.textViewcasesWorld)?.setText("6.161.487")
        rootView?.findViewById<TextView>(R.id.textViewDeadsWorld)?.setText("371.016")
        rootView?.findViewById<TextView>(R.id.textViewNewCasesWorld)?.setText("11.004")
        rootView?.findViewById<TextView>(R.id.textViewNewDeadsWorld)?.setText("510")



        rootView?.findViewById<TextView>(R.id.textViewCountry)?.setText("Chile")
        rootView?.findViewById<TextView>(R.id.textViewCasesCountry)?.setText("94.858")
        rootView?.findViewById<TextView>(R.id.textViewDeadsCountry)?.setText("997")

        rootView?.findViewById<TextView>(R.id.textViewNewCasesCountry)?.setText("1502")
        rootView?.findViewById<TextView>(R.id.textViewNewDeadsCountry)?.setText("41")


        rootView?.findViewById<TextView>(R.id.textViewRegion)?.setText("Santiago")
        rootView?.findViewById<TextView>(R.id.textViewCasesRegion)?.setText("89665")
        rootView?.findViewById<TextView>(R.id.textViewDeadsRegion)?.setText("857")

        rootView?.findViewById<TextView>(R.id.textViewNewCasesRegion)?.setText("1502")
        rootView?.findViewById<TextView>(R.id.textViewNewDeadsRegion)?.setText("41")


    }
}
