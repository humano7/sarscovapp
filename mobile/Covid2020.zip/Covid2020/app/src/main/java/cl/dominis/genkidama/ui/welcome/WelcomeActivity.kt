package cl.dominis.genkidama.ui.welcome

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Html
import androidx.appcompat.app.AppCompatActivity
import cl.dominis.genkidama.MainActivity
import cl.dominis.genkidama.R
import kotlinx.android.synthetic.main.activity_welcome.*

class WelcomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        setData()
        setListeners()
    }

    fun setData()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            welcome_text.setText(Html.fromHtml(getString(R.string.welcome_text), Html.FROM_HTML_MODE_COMPACT));
        } else {
            welcome_text.setText(Html.fromHtml(getString(R.string.welcome_text)));
        }
    }


    fun setListeners()
    {
        butonContinue.setOnClickListener({
            goMainActivity()
        })
    }

    fun goMainActivity()
    {
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}