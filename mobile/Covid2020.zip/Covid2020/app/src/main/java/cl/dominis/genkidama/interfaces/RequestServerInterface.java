package cl.dominis.genkidama.interfaces;

import android.content.Context;

/**
 * Created by szepeda on 22-03-16.
 */
public interface RequestServerInterface {
    /**
     * Get context data
     * @return
     */
    Context getContext();

    /**
     * Server response data
     * @param response data
     * @param result result object
     * @param flag
     */
    void returnData(String response, Object result, int flag);
}
