package cl.dominis.genkidama.ui.form

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import cl.dominis.genkidama.R
import com.google.android.material.button.MaterialButton
import kotlinx.android.synthetic.main.fragment_form.*


class FormFragment : Fragment() {

    private lateinit var notificationsViewModel: FormViewModel
    private lateinit var root  : View
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        notificationsViewModel =
                ViewModelProviders.of(this).get(FormViewModel::class.java)
        root = inflater.inflate(R.layout.fragment_form, container, false)
        setListeners()
        return root
    }

    fun setListeners()
    {
        root.findViewById<MaterialButton>(R.id.butonCheck).setOnClickListener(View.OnClickListener { checkStatus() })
    }

    fun checkStatus()
    {
        var points = 0

        if(switchFever.isChecked)
        {
            points  = points+1
        }
        if(switchCough.isChecked)
        {
            points = points+1
        }

        if(switchFeel.isChecked)
        {
            points = points+1
        }

        if(switchBreath.isChecked)
        {
            points = points+3
        }

        if(switchChest.isChecked)
        {
            points = points+3
        }

        if(switchMove.isChecked)
        {
            points = points+3
        }

        if(points == 0)
        {
            setDialog(getString(R.string.risk_low))
            return;
        }
        if(points < 4)
        {
            setDialog(getString(R.string.risk_medium))
            return;
        }

        setDialog(getString(R.string.risk_high))

    }

    fun setDialog(text : String)
    {
        AlertDialog.Builder(activity!!)
            .setTitle(getString(R.string.risk_title))
            .setMessage(text) // Specifying a listener allows you to take an action before dismissing the dialog.
            // The dialog is automatically dismissed when a dialog button is clicked.
            .setPositiveButton(android.R.string.yes,
                DialogInterface.OnClickListener { dialog, which ->
                    // Continue with delete operation
                }) // A null listener allows the button to dismiss the dialog and take no further action.
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }
}
