package cl.dominis.genkidama.controllers.services;


import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;



import java.security.KeyStoreException;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import cl.dominis.genkidama.interfaces.RequestServerInterface;


/**
 * Created by szepeda on 22-03-16.
 */
public class MainRequest {


    private String url;
    private int flag;


    private RequestServerInterface serverInterface;

    /** The default socket timeout in milliseconds */
    private int DEFAULT_TIMEOUT_MS;

    /** The default number of retries */
    private int DEFAULT_MAX_RETRIES;

    /** The default backoff multiplier */
    public static  float DEFAULT_BACKOFF_MULT = 1f;

    public static RequestQueue requestQueue;

    HurlStack hurlStack;
    public boolean isHttps = false;



    public MainRequest(RequestServerInterface serverInterface)
    {
        this.serverInterface = serverInterface;
    }
    public void requestGet( String urlIn, int flag)
    {
        this.flag = flag;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, urlIn,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Toast.makeText(MainActivity.this,response,Toast.LENGTH_LONG).show();
                        processResponse(response,false);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                        processResponse("",true);
                    }
                }){


        };
        /*
        requestQueue = Volley.newRequestQueue(serverInterface.getContext());
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
            (int) TimeUnit.SECONDS.toMillis(20),
            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);*/

        if(isHttps)
        {
            requestQueue = Volley.newRequestQueue(serverInterface.getContext(),hurlStack);
        }
        else
        {
            requestQueue = Volley.newRequestQueue(serverInterface.getContext());
        }

        //requestQueue = Volley.newRequestQueue(serverInterface.getContext());
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                (int) TimeUnit.SECONDS.toMillis(20),
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));


        requestQueue.add(stringRequest);
    }

    /**
     * Process and return response
     * @param response String response
     * @param hasError true if is a error
     */
    private void processResponse(String response, boolean hasError)
    {
        requestQueue.getCache().clear();
        Log.i("RX", flag+" response: "+ response  + "\n hasError: "+ hasError );
        //if(hasError)
        {
            serverInterface.returnData(response,hasError,flag);
        }

    }




}
